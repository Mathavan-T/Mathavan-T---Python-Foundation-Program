import unittest
import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from dao.OrderProcessorRepositoryImpl import OrderProcessorRepositoryImpl
from entity.Customer import Customer
from entity.Product import Product

class TestEcommerceApp(unittest.TestCase):

    def setUp(self):
        self.repo = OrderProcessorRepositoryImpl()
        cursor = self.repo.conn.cursor()

        cursor.execute("DELETE FROM cart")
        cursor.execute("DELETE FROM order_items")
        cursor.execute("DELETE FROM orders")
        cursor.execute("DELETE FROM customers WHERE email = 'test@example.com'")
        cursor.execute("DELETE FROM products WHERE name = 'Test Product'")
        self.repo.conn.commit()

        self.test_customer = Customer(name="Test User", email="test@example.com", password="pass123")
        self.repo.create_customer(self.test_customer)

        cursor.execute("SELECT customer_id FROM customers WHERE email = %s", (self.test_customer.get_email(),))
        row = cursor.fetchone()
        if row:
            self.test_customer.set_customer_id(row[0])

        self.test_product = Product(name="Test Product", price=100.0, description="Demo", stock_quantity=10)
        self.repo.create_product(self.test_product)

        cursor.execute("SELECT product_id FROM products WHERE name = %s", (self.test_product.get_name(),))
        row = cursor.fetchone()
        if row:
            self.test_product.set_product_id(row[0])

        self.repo.conn.commit()

    def test_1_create_customer(self):
        self.assertIsNotNone(self.test_customer.get_customer_id())

    def test_2_create_product(self):
        self.assertIsNotNone(self.test_product.get_product_id())

    def test_3_add_to_cart(self):
        result = self.repo.add_to_cart(self.test_customer, self.test_product, 2)
        self.assertTrue(result)

    def test_4_remove_from_cart(self):
        self.repo.add_to_cart(self.test_customer, self.test_product, 1)  
        result = self.repo.remove_from_cart(self.test_customer, self.test_product)
        self.assertTrue(result)

    def test_5_get_cart(self):
        self.repo.add_to_cart(self.test_customer, self.test_product, 1)
        cart_items = self.repo.get_all_from_cart(self.test_customer)
        self.assertIsInstance(cart_items, list)
        self.assertGreaterEqual(len(cart_items), 1)

if __name__ == '__main__':
    unittest.main()
from dao.OrderProcessorRepositoryImpl import OrderProcessorRepositoryImpl
from entity.Customer import Customer
from entity.Product import Product

repo = OrderProcessorRepositoryImpl()

customer = Customer(name="Mohan T", email="mohan@example.com", password="pass123")
if repo.create_customer(customer):
    print("✅ Customer created successfully")
else:
    print("❌ Customer creation failed")

product = Product(name="Bluetooth Speaker", price=1499.99, description="Portable speaker", stock_quantity=10)
if repo.create_product(product):
    print("✅ Product created successfully")
else:
    print("❌ Product creation failed")

customer.set_customer_id(2) 
product.set_product_id(2)   

if repo.add_to_cart(customer, product, 3):
    print("✅ Product added to cart")
else:
    print("❌ Failed to add product to cart")

cart_items = repo.get_all_from_cart(customer)
if cart_items:
    print("🛒 Cart Contents:")
    for item in cart_items:
        p, qty = item
        print(f"- {p.get_name()} | Qty: {qty} | ₹{p.get_price()}")
else:
    print("🛒 Cart is empty or fetch failed")

if repo.remove_from_cart(customer, product):
    print("✅ Product removed from cart")
else:
    print("❌ Failed to remove product from cart")

if repo.delete_customer(1):
    print("✅ Customer deleted successfully")
else:
    print("❌ Customer deletion failed or not found")

if repo.delete_product(1):
    print("✅ Product deleted successfully")
else:
    print("❌ Product deletion failed or not found")
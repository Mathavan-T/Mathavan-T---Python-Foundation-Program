import mysql.connector
from util.DBPropertyUtil import DBPropertyUtil

class DBConnUtil:
    @staticmethod
    def get_connection():
        try:
            config = DBPropertyUtil.get_property_string()

            if not all(config.values()):
                raise ValueError(f"❌ One or more DB config values are missing: {config}")

            config['port'] = int(config['port']) 
            connection = mysql.connector.connect(**config)
            return connection

        except mysql.connector.Error as err:
            print(f"❌ MySQL connection error: {err}")
            return None

        except Exception as e:
            print(f"❌ Config error: {e}")
            return None
import configparser
import os

class DBPropertyUtil:
    @staticmethod
    def get_property_string(filename='util/db.properties'):
        project_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        file_path = os.path.join(project_dir, filename)

        print(f"📁 Reading DB config from: {file_path}")  

        config = configparser.ConfigParser()
        config.read(file_path)

        if 'DEFAULT' not in config:
            raise Exception("❌ 'DEFAULT' section not found in properties file.")

        db_config = config['DEFAULT']
        print("🔍 Loaded config values:")
        for key in db_config:
            print(f"   {key} = {db_config[key]}") 

        return {
            'host': db_config.get('host'),
            'port': db_config.get('port'),
            'user': db_config.get('user'),
            'password': db_config.get('password'),
            'database': db_config.get('database')
        }
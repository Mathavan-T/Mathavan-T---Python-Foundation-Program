from util.DBConnUtil import DBConnUtil

conn = DBConnUtil.get_connection()
if conn:
    print("✅ Connected to DB successfully!")
    conn.close()
else:
    print("❌ Connection failed.")
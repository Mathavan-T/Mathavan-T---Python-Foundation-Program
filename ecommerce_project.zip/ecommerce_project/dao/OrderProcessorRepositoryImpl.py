from util.DBConnUtil import DBConnUtil
from entity.Customer import Customer
from entity.Product import Product
from datetime import datetime

class OrderProcessorRepositoryImpl:
    def __init__(self):
        self.conn = DBConnUtil.get_connection()

    def create_customer(self, customer):
        try:
            cursor = self.conn.cursor()
            sql = "INSERT INTO customers (name, email, password) VALUES (%s, %s, %s)"
            cursor.execute(sql, (customer.get_name(), customer.get_email(), customer.get_password()))
            self.conn.commit()
            return True
        except Exception as e:
            print("❌ Error creating customer:", e)
            return False

    def create_product(self, product):
        try:
            cursor = self.conn.cursor()
            sql = "INSERT INTO products (name, price, description, stockQuantity) VALUES (%s, %s, %s, %s)"
            cursor.execute(sql, (product.get_name(), product.get_price(), product.get_description(), product.get_stock_quantity()))
            self.conn.commit()
            return True
        except Exception as e:
            print("❌ Error creating product:", e)
            return False

    def delete_customer(self, customer_id):
        try:
            cursor = self.conn.cursor()
            sql = "DELETE FROM customers WHERE customer_id = %s"
            cursor.execute(sql, (customer_id,))
            self.conn.commit()
            if cursor.rowcount == 0:
                print("❌ No customer found with ID:", customer_id)
                return False
            return True
        except Exception as e:
            print("❌ Error deleting customer:", e)
            return False

    def delete_product(self, product_id):
        try:
            cursor = self.conn.cursor()
            sql = "DELETE FROM products WHERE product_id = %s"
            cursor.execute(sql, (product_id,))
            self.conn.commit()
            if cursor.rowcount == 0:
                print("❌ No product found with ID:", product_id)
                return False
            return True
        except Exception as e:
            print("❌ Error deleting product:", e)
            return False

    def add_to_cart(self, customer, product, quantity):
        try:
            cursor = self.conn.cursor()
            sql = """
                INSERT INTO cart (customer_id, product_id, quantity)
                VALUES (%s, %s, %s)
                ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)
            """
            cursor.execute(sql, (
                customer.get_customer_id(),
                product.get_product_id(),
                quantity
            ))
            self.conn.commit()
            return True
        except Exception as e:
            print("❌ Error adding to cart:", e)
            return False

    def remove_from_cart(self, customer, product):
        try:
            cursor = self.conn.cursor()
            sql = "DELETE FROM cart WHERE customer_id = %s AND product_id = %s"
            cursor.execute(sql, (
                customer.get_customer_id(),
                product.get_product_id()
            ))
            self.conn.commit()
            if cursor.rowcount == 0:
                print("❌ Item not found in cart")
                return False
            return True
        except Exception as e:
            print("❌ Error removing from cart:", e)
            return False

    def get_all_from_cart(self, customer):
        try:
            cursor = self.conn.cursor()
            sql = """
                SELECT p.product_id, p.name, p.price, p.description, c.quantity
                FROM cart c
                JOIN products p ON c.product_id = p.product_id
                WHERE c.customer_id = %s
            """
            cursor.execute(sql, (customer.get_customer_id(),))
            rows = cursor.fetchall()

            cart_items = []
            for row in rows:
                product = Product(
                    product_id=row[0],
                    name=row[1],
                    price=row[2],
                    description=row[3],
                    stock_quantity=0
                )
                cart_items.append((product, row[4]))  

            return cart_items
        except Exception as e:
            print("❌ Error fetching cart items:", e)
            return []

    def place_order(self, customer, product_quantity_list, shipping_address):
        try:
            cursor = self.conn.cursor()

            total_price = 0
            for product, qty in product_quantity_list:
                total_price += product.get_price() * qty

            order_sql = """
                INSERT INTO orders (customer_id, order_date, total_price, shipping_address)
                VALUES (%s, %s, %s, %s)
            """
            order_date = datetime.now()
            cursor.execute(order_sql, (customer.get_customer_id(), order_date, total_price, shipping_address))
            order_id = cursor.lastrowid

            item_sql = """
                INSERT INTO order_items (order_id, product_id, quantity)
                VALUES (%s, %s, %s)
            """
            for product, qty in product_quantity_list:
                cursor.execute(item_sql, (order_id, product.get_product_id(), qty))

            clear_sql = "DELETE FROM cart WHERE customer_id = %s"
            cursor.execute(clear_sql, (customer.get_customer_id(),))

            self.conn.commit()
            return True
        except Exception as e:
            print("❌ Error placing order:", e)
            self.conn.rollback()
            return False

    def get_orders_by_customer(self, customer_id):
        try:
            cursor = self.conn.cursor()
            sql = """
                SELECT o.order_id, o.order_date, o.total_price, o.shipping_address,
                       p.name, p.price, oi.quantity
                FROM orders o
                JOIN order_items oi ON o.order_id = oi.order_id
                JOIN products p ON oi.product_id = p.product_id
                WHERE o.customer_id = %s
                ORDER BY o.order_id DESC
            """
            cursor.execute(sql, (customer_id,))
            return cursor.fetchall()
        except Exception as e:
            print("❌ Error fetching orders:", e)
            return []
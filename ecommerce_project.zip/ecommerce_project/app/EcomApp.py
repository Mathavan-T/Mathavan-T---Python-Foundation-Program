import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from dao.OrderProcessorRepositoryImpl import OrderProcessorRepositoryImpl
from entity.Customer import Customer
from entity.Product import Product

def main():
    repo = OrderProcessorRepositoryImpl()
    customer = None  

    while True:
        print("\n====== ECOMMERCE MENU ======")
        print("1. Register Customer")
        print("2. Create Product")
        print("3. Delete Product")
        print("4. Add to Cart")
        print("5. View Cart")
        print("6. Remove from Cart")
        print("7. Place Order")
        print("8. View Orders")
        print("9. Exit")
        print("============================")
        choice = input("Enter your choice: ")

        if choice == '1':
            name = input("Enter customer name: ")
            email = input("Enter email: ")
            password = input("Enter password: ")
            customer = Customer(name=name, email=email, password=password)
            if repo.create_customer(customer):
                print("✅ Customer registered successfully.")
                customer_id = int(input("Enter customer ID from DB: "))
                customer.set_customer_id(customer_id)
            else:
                print("❌ Registration failed.")

        elif choice == '2':
            name = input("Enter product name: ")
            price = float(input("Enter price: "))
            desc = input("Enter description: ")
            stock = int(input("Enter stock quantity: "))
            product = Product(name=name, price=price, description=desc, stock_quantity=stock)
            if repo.create_product(product):
                print("✅ Product added.")
            else:
                print("❌ Failed to add product.")

        elif choice == '3':
            pid = int(input("Enter product ID to delete: "))
            if repo.delete_product(pid):
                print("✅ Product deleted.")
            else:
                print("❌ Product not found.")

        elif choice == '4':
            if not customer:
                print("⚠️ Please register first.")
                continue
            pid = int(input("Enter product ID to add: "))
            qty = int(input("Enter quantity: "))
            product = Product(product_id=pid)
            if repo.add_to_cart(customer, product, qty):
                print("✅ Added to cart.")
            else:
                print("❌ Failed to add.")

        elif choice == '5':
            if not customer:
                print("⚠️ Please register first.")
                continue
            cart_items = repo.get_all_from_cart(customer)
            if cart_items:
                print("🛒 Cart:")
                for p, q in cart_items:
                    print(f"{p.get_name()} - ₹{p.get_price()} x {q}")
            else:
                print("🛒 Cart is empty.")

        elif choice == '6':
            if not customer:
                print("⚠️ Please register first.")
                continue
            pid = int(input("Enter product ID to remove from cart: "))
            product = Product(product_id=pid)
            if repo.remove_from_cart(customer, product):
                print("✅ Removed from cart.")
            else:
                print("❌ Not found in cart.")

        elif choice == '7':
            if not customer:
                print("⚠️ Please register first.")
                continue
            cart_items = repo.get_all_from_cart(customer)
            if not cart_items:
                print("❌ Cart is empty.")
                continue
            shipping = input("Enter shipping address: ")
            if repo.place_order(customer, cart_items, shipping):
                print("✅ Order placed successfully.")
            else:
                print("❌ Failed to place order.")

        elif choice == '8':
            if not customer:
                print("⚠️ Please register first.")
                continue
            orders = repo.get_orders_by_customer(customer.get_customer_id())
            if orders:
                print("📦 Orders:")
                for o in orders:
                    oid, date, total, addr, pname, price, qty = o
                    print(f"Order #{oid} | {date} | {pname} x{qty} | ₹{total}")
            else:
                print("❌ No orders found.")

        elif choice == '9':
            print("👋 Exiting. Thank you!")
            break

        else:
            print("❌ Invalid choice.")

if __name__ == "__main__":
    main()